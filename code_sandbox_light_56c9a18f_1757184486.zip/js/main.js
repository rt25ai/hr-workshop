// Main JavaScript for AI PRO Landing Page

// Accessibility Functions
let fontSize = 100;
let highContrast = false;
let linksHighlighted = false;
let animationsStopped = false;

// Make all accessibility functions global
window.adjustFontSize = function(action) {
    if (action === 'increase' && fontSize < 150) {
        fontSize += 10;
    } else if (action === 'decrease' && fontSize > 70) {
        fontSize -= 10;
    }
    document.documentElement.style.fontSize = fontSize + '%';
    localStorage.setItem('fontSize', fontSize);
}

window.toggleHighContrast = function() {
    highContrast = !highContrast;
    if (highContrast) {
        document.body.classList.add('high-contrast');
        // Add high contrast styles
        let style = document.getElementById('high-contrast-styles');
        if (!style) {
            style = document.createElement('style');
            style.id = 'high-contrast-styles';
            style.textContent = `
                .high-contrast * {
                    background: white !important;
                    color: black !important;
                    border-color: black !important;
                }
                .high-contrast a {
                    color: blue !important;
                    text-decoration: underline !important;
                }
                .high-contrast button {
                    background: black !important;
                    color: white !important;
                    border: 2px solid black !important;
                }
            `;
            document.head.appendChild(style);
        }
    } else {
        document.body.classList.remove('high-contrast');
        const style = document.getElementById('high-contrast-styles');
        if (style) style.remove();
    }
    localStorage.setItem('highContrast', highContrast);
}

window.highlightLinks = function() {
    linksHighlighted = !linksHighlighted;
    const links = document.querySelectorAll('a, button');
    links.forEach(link => {
        if (linksHighlighted) {
            link.style.outline = '2px solid orange';
            link.style.outlineOffset = '2px';
        } else {
            link.style.outline = '';
            link.style.outlineOffset = '';
        }
    });
    localStorage.setItem('linksHighlighted', linksHighlighted);
}

window.stopAnimations = function() {
    animationsStopped = !animationsStopped;
    if (animationsStopped) {
        let style = document.getElementById('stop-animations');
        if (!style) {
            style = document.createElement('style');
            style.id = 'stop-animations';
            style.textContent = `
                *, *::before, *::after {
                    animation-duration: 0.01ms !important;
                    animation-iteration-count: 1 !important;
                    transition-duration: 0.01ms !important;
                    scroll-behavior: auto !important;
                }
            `;
            document.head.appendChild(style);
        }
    } else {
        const style = document.getElementById('stop-animations');
        if (style) style.remove();
    }
    localStorage.setItem('animationsStopped', animationsStopped);
}

// Alt text toggle function
let altTextsVisible = false;
window.toggleAltTexts = function() {
    altTextsVisible = !altTextsVisible;
    const elementsWithAlt = document.querySelectorAll('[role="img"]');
    
    elementsWithAlt.forEach(element => {
        if (altTextsVisible) {
            // Create or update alt text display
            let altDisplay = element.querySelector('.alt-text-display');
            if (!altDisplay) {
                altDisplay = document.createElement('div');
                altDisplay.className = 'alt-text-display absolute bg-black text-white text-xs p-1 rounded mt-1 z-50';
                altDisplay.style.fontSize = '12px';
                altDisplay.style.maxWidth = '200px';
                element.style.position = 'relative';
                element.appendChild(altDisplay);
            }
            altDisplay.textContent = element.getAttribute('aria-label') || 'תיאור לא זמין';
            altDisplay.style.display = 'block';
        } else {
            // Hide alt text displays
            const altDisplay = element.querySelector('.alt-text-display');
            if (altDisplay) {
                altDisplay.style.display = 'none';
            }
        }
    });
    
    localStorage.setItem('altTextsVisible', altTextsVisible);
}

window.resetAccessibility = function() {
    fontSize = 100;
    document.documentElement.style.fontSize = '100%';
    
    if (highContrast) window.toggleHighContrast();
    if (linksHighlighted) window.highlightLinks();
    if (animationsStopped) window.stopAnimations();
    if (altTextsVisible) window.toggleAltTexts();
    
    localStorage.removeItem('fontSize');
    localStorage.removeItem('highContrast');
    localStorage.removeItem('linksHighlighted');
    localStorage.removeItem('animationsStopped');
    localStorage.removeItem('altTextsVisible');
}

// Modal Functions - Make them global
window.openModal = function(modalType) {
    const modal = document.getElementById(modalType + '-modal');
    if (modal) {
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
}

window.closeModal = function(modalType) {
    const modal = document.getElementById(modalType + '-modal');
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = '';
    }
}

// Load accessibility settings from localStorage
window.loadAccessibilitySettings = function() {
    const savedFontSize = localStorage.getItem('fontSize');
    if (savedFontSize) {
        fontSize = parseInt(savedFontSize);
        document.documentElement.style.fontSize = fontSize + '%';
    }
    
    const savedHighContrast = localStorage.getItem('highContrast');
    if (savedHighContrast === 'true') {
        toggleHighContrast();
    }
    
    const savedLinksHighlighted = localStorage.getItem('linksHighlighted');
    if (savedLinksHighlighted === 'true') {
        highlightLinks();
    }
    
    const savedAnimationsStopped = localStorage.getItem('animationsStopped');
    if (savedAnimationsStopped === 'true') {
        stopAnimations();
    }
    
    const savedAltTextsVisible = localStorage.getItem('altTextsVisible');
    if (savedAltTextsVisible === 'true') {
        toggleAltTexts();
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Load accessibility settings on page load
    window.loadAccessibilitySettings();
    
    // Log webhook status
    console.log('🔗 Webhook מוגדר:', 'https://hook.eu2.make.com/p2gjr4ddsffx44yvxeef6wh6532pspd1');
    console.log('🚀 מערכת webhook מוכנה לקבלת הרשמות');
    
    // Initialize advanced accessibility widget
    const accessibilityWidget = document.getElementById('accessibility-widget-btn');
    const accessibilityPanel = document.getElementById('accessibility-panel');
    
    if (accessibilityWidget && accessibilityPanel) {
        accessibilityWidget.addEventListener('click', function() {
            accessibilityPanel.classList.toggle('hidden');
        });
        
        // Close panel when clicking outside
        document.addEventListener('click', function(e) {
            if (!accessibilityWidget.contains(e.target) && !accessibilityPanel.contains(e.target)) {
                accessibilityPanel.classList.add('hidden');
            }
        });
    }
    
    // Accessibility menu toggle
    const accessibilityBtn = document.getElementById('accessibility-btn');
    const accessibilityMenu = document.getElementById('accessibility-menu');
    
    if (accessibilityBtn && accessibilityMenu) {
        accessibilityBtn.addEventListener('click', function() {
            accessibilityMenu.classList.toggle('hidden');
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!accessibilityBtn.contains(e.target) && !accessibilityMenu.contains(e.target)) {
                accessibilityMenu.classList.add('hidden');
            }
        });
    }
    
    // Add ARIA labels to form fields
    const formInputs = document.querySelectorAll('input, textarea, select');
    formInputs.forEach(input => {
        if (!input.getAttribute('aria-label')) {
            const label = input.getAttribute('placeholder') || input.getAttribute('name');
            if (label) {
                input.setAttribute('aria-label', label);
            }
        }
    });
    
    // Add keyboard navigation support
    document.addEventListener('keydown', function(e) {
        // Escape key closes modals and accessibility menu
        if (e.key === 'Escape') {
            window.closeModal('terms');
            window.closeModal('privacy');
            window.closeModal('accessibility');
            if (accessibilityMenu) {
                accessibilityMenu.classList.add('hidden');
            }
        }
    });
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // FAQ Toggle functionality
    const faqToggles = document.querySelectorAll('.faq-toggle');
    faqToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const answer = this.nextElementSibling;
            const chevron = this.querySelector('i');
            
            // Toggle visibility
            answer.classList.toggle('hidden');
            
            // Rotate chevron
            if (answer.classList.contains('hidden')) {
                chevron.style.transform = 'rotate(0deg)';
            } else {
                chevron.style.transform = 'rotate(180deg)';
            }
            
            // Close other FAQs
            faqToggles.forEach(otherToggle => {
                if (otherToggle !== toggle) {
                    const otherAnswer = otherToggle.nextElementSibling;
                    const otherChevron = otherToggle.querySelector('i');
                    otherAnswer.classList.add('hidden');
                    otherChevron.style.transform = 'rotate(0deg)';
                }
            });
        });
    });

    // Form submission handler - Handle both forms
    const registrationForm = document.getElementById('registration-form');
    const heroForm = document.getElementById('hero-form');
    const successMessage = document.getElementById('success-message');
    
    function handleFormSubmit(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data from form elements directly
            const formInputs = this.querySelectorAll('input, textarea, select');
            const data = {};
            
            // Extract data from each form field
            formInputs.forEach(input => {
                if (input.name && input.value.trim() !== '') {
                    data[input.name] = input.value.trim();
                    console.log(`📝 שדה ${input.name}: "${input.value.trim()}"`);
                } else if (input.name) {
                    console.log(`⚠️ שדה ריק: ${input.name}`);
                }
            });
            
            // Add metadata
            data.timestamp = new Date().toISOString();
            data.source = 'hr-workshop.rt-ai.co.il';
            data.form_type = this.id;
            data.user_agent = navigator.userAgent;
            data.page_url = window.location.href;
            
            // Validate essential data exists
            const requiredFields = data.form_type === 'hero-form' 
                ? ['email', 'name'] 
                : ['fullName', 'position', 'email'];
                
            const missingFields = requiredFields.filter(field => !data[field]);
            if (missingFields.length > 0) {
                console.error('❌ שדות חובה חסרים:', missingFields);
                alert('אנא מלא את כל השדות הנדרשים: ' + missingFields.join(', '));
                return;
            }
            
            // Log form data
            console.log('✅ נתוני הרשמה מוכנים לשליחה:', data);
            
            // Send data to webhook
            sendToWebhook(data, this);
        });
    }
    
    // Webhook configuration - Active Make.com webhook
    const WEBHOOK_CONFIG = {
        primary: 'https://hook.eu2.make.com/p2gjr4ddsffx44yvxeef6wh6532pspd1', // Active Make.com webhook
        backup: 'https://hooks.zapier.com/hooks/catch/YOUR_ZAPIER_ID/', // Replace with your Zapier webhook if needed
        email: 'https://formspree.io/f/YOUR_FORM_ID' // Replace with your Formspree form ID if needed
    };
    
    async function sendToWebhook(data, form) {
        const submitButton = form.querySelector('button[type="submit"]');
        const originalText = submitButton.innerHTML;
        
        // Show loading state
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin ml-2"></i>שולח...';
        
        // Log webhook attempt with detailed data
        console.log('🚀 שולח ל-Make.com webhook:', WEBHOOK_CONFIG.primary);
        console.log('📊 נתונים נשלחים:');
        console.log('   📝 Form ID:', data.form_type);
        console.log('   👤 Full Name:', data.fullName || data.name);
        console.log('   💼 Position:', data.position);
        console.log('   📧 Email:', data.email);
        console.log('   📱 Phone:', data.phone);
        console.log('   🏢 Organization:', data.organization);
        console.log('   💬 Questions:', data.questions);
        console.log('   🕐 Timestamp:', data.timestamp);
        console.log('   🔗 Source:', data.source);
        console.log('   🖥️ User Agent:', data.user_agent?.substring(0, 50) + '...');
        console.log('   📍 Page URL:', data.page_url);
        console.log('📦 מבנה מלא:', data);
        
        try {
            // Try multiple formats for Make.com compatibility
            console.log('🔄 מנסה פורמט JSON...');
            let response = await fetch(WEBHOOK_CONFIG.primary, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            // If JSON doesn't work, try form-encoded data
            if (!response.ok) {
                console.log('🔄 JSON נכשל, מנסה form-encoded...');
                const formData = new FormData();
                Object.keys(data).forEach(key => {
                    formData.append(key, data[key]);
                });
                
                response = await fetch(WEBHOOK_CONFIG.primary, {
                    method: 'POST',
                    body: formData
                });
            }
            
            // If form-data doesn't work, try URL-encoded
            if (!response.ok) {
                console.log('🔄 Form-data נכשל, מנסה URL-encoded...');
                const params = new URLSearchParams();
                Object.keys(data).forEach(key => {
                    params.append(key, data[key]);
                });
                
                response = await fetch(WEBHOOK_CONFIG.primary, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: params
                });
            }
            
            // If URL-encoded doesn't work, try email format (for Make.com Email Webhook)
            if (!response.ok) {
                console.log('🔄 URL-encoded נכשל, מנסה פורמט מייל...');
                const emailFormatData = {
                    to: 'roi@rt-ai.co.il',
                    from: data.email || 'noreply@rt-ai.co.il',
                    subject: `הרשמה חדשה לסדנת AI PRO מ-${data.fullName || data.name}`,
                    text: `הרשמה חדשה לסדנת AI PRO:

📝 שם מלא: ${data.fullName || data.name}
💼 תפקיד: ${data.position || 'לא צוין'}
📧 אימייל: ${data.email}
📱 טלפון: ${data.phone}
🏢 ארגון: ${data.organization || 'לא צוין'}
💬 שאלות: ${data.questions || 'אין'}

🕐 זמן הרשמה: ${data.timestamp}
🔗 מקור: ${data.source}
📋 סוג טופס: ${data.form_type}`,
                    html: `
                        <h2>🎯 הרשמה חדשה לסדנת AI PRO</h2>
                        <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; font-family: Arial;">
                            <h3>פרטי המשתתף:</h3>
                            <p><strong>📝 שם מלא:</strong> ${data.fullName || data.name}</p>
                            <p><strong>💼 תפקיד:</strong> ${data.position || 'לא צוין'}</p>
                            <p><strong>📧 אימייל:</strong> ${data.email}</p>
                            <p><strong>📱 טלפון:</strong> ${data.phone}</p>
                            <p><strong>🏢 ארגון:</strong> ${data.organization || 'לא צוין'}</p>
                            <p><strong>💬 שאלות:</strong> ${data.questions || 'אין'}</p>
                            
                            <hr style="margin: 20px 0;">
                            <h3>מידע טכני:</h3>
                            <p><small><strong>🕐 זמן הרשמה:</strong> ${data.timestamp}</small></p>
                            <p><small><strong>🔗 מקור:</strong> ${data.source}</small></p>
                            <p><small><strong>📋 סוג טופס:</strong> ${data.form_type}</small></p>
                        </div>
                    `
                };
                
                response = await fetch(WEBHOOK_CONFIG.primary, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(emailFormatData)
                });
            }
            
            console.log('📡 תגובת שרת:', {
                status: response.status,
                statusText: response.statusText,
                ok: response.ok
            });
            
            // Try to read response content
            try {
                const responseText = await response.text();
                console.log('📄 תוכן תגובה:', responseText);
            } catch (e) {
                console.log('📄 לא ניתן לקרוא תגובה');
            }
            
            if (response.ok || response.status === 200) {
                showSuccessMessage(form);
                console.log('✅ נשלח בהצלחה ל-Make.com webhook!');
            } else {
                console.warn('⚠️ Make.com webhook החזיר שגיאה:', response.status);
                throw new Error(`Make.com webhook failed: ${response.status}`);
            }
            
        } catch (error) {
            console.warn('⚠️ Webhook ראשי נכשל, מנסה backup...', error);
            
            try {
                // Try backup webhook
                await fetch(WEBHOOK_CONFIG.backup, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });
                
                showSuccessMessage(form);
                console.log('✅ נשלח בהצלחה לwebhook backup');
                
            } catch (backupError) {
                console.warn('⚠️ Backup webhook נכשל, מנסה email fallback...', backupError);
                
                try {
                    // Try email fallback (Formspree)
                    const emailFormData = new FormData();
                    Object.keys(data).forEach(key => {
                        emailFormData.append(key, data[key]);
                    });
                    
                    await fetch(WEBHOOK_CONFIG.email, {
                        method: 'POST',
                        body: emailFormData,
                        headers: {
                            'Accept': 'application/json'
                        }
                    });
                    
                    showSuccessMessage(form);
                    console.log('✅ נשלח בהצלחה באמצעות email fallback');
                    
                } catch (emailError) {
                    console.error('❌ כל הwebhooks נכשלו:', emailError);
                    showErrorMessage(form);
                }
            }
        } finally {
            // Reset button state
            submitButton.disabled = false;
            submitButton.innerHTML = originalText;
        }
    }
    
    function showSuccessMessage(form) {
        // Reset form only AFTER successful webhook send
        form.reset();
        
        // For hero form, scroll to main registration section
        if (form.id === 'hero-form') {
            const registerSection = document.getElementById('register');
            if (registerSection) {
                registerSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
        
        const successMessage = document.getElementById('success-message');
        if (successMessage) {
            successMessage.classList.remove('hidden');
            successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // Hide success message after 5 seconds
            setTimeout(() => {
                successMessage.classList.add('hidden');
            }, 5000);
        }
        
        // Send to analytics
        if (typeof gtag !== 'undefined') {
            gtag('event', 'form_submit', {
                'event_category': 'engagement',
                'event_label': 'registration_success',
                'form_id': form.id
            });
        }
    }
    
    function showErrorMessage(form) {
        // Create or show error message
        let errorDiv = document.getElementById('error-message');
        if (!errorDiv) {
            errorDiv = document.createElement('div');
            errorDiv.id = 'error-message';
            errorDiv.className = 'fixed top-4 left-1/2 transform -translate-x-1/2 bg-red-500 text-white p-4 rounded-lg shadow-lg z-50 max-w-md text-center';
            errorDiv.innerHTML = `
                <i class="fas fa-exclamation-triangle ml-2"></i>
                <strong>שגיאה בשליחה</strong><br>
                אנא נסה שוב או צור קשר ישירות: <a href="tel:0523299985" class="underline">052-3299985</a>
            `;
            document.body.appendChild(errorDiv);
        }
        
        errorDiv.classList.remove('hidden');
        
        // Hide error message after 7 seconds
        setTimeout(() => {
            errorDiv.classList.add('hidden');
        }, 7000);
        
        // Send to analytics
        if (typeof gtag !== 'undefined') {
            gtag('event', 'form_error', {
                'event_category': 'error',
                'event_label': 'registration_failed',
                'form_id': form.id
            });
        }
    }
    
    if (registrationForm) {
        handleFormSubmit(registrationForm);
    }
    
    if (heroForm) {
        handleFormSubmit(heroForm);
    }
    
    // Webhook connection test function (for debugging)
    window.testWebhook = async function() {
        console.log('🧪 בודק חיבור ל-Make.com webhook...');
        
        const testData = {
            fullName: 'רועי טל - בדיקה טכנית',
            position: 'מומחה בינה מלאכותית',
            email: 'test@rt-ai.co.il',
            phone: '052-3299985',
            organization: 'RT-AI Solutions',
            questions: 'זו בדיקה טכנית של מערכת ההרשמה לסדנת AI PRO',
            timestamp: new Date().toISOString(),
            source: 'hr-workshop.rt-ai.co.il',
            form_type: 'manual_test',
            user_agent: navigator.userAgent,
            page_url: window.location.href,
            test_mode: true,
            test_description: 'Manual webhook test from browser console'
        };
        
        console.log('📋 נתוני בדיקה:');
        Object.entries(testData).forEach(([key, value]) => {
            console.log(`   ${key}: ${value}`);
        });
        
        try {
            const response = await fetch(WEBHOOK_CONFIG.primary, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(testData)
            });
            
            if (response.ok) {
                console.log('✅ בדיקת webhook הצליחה!', response.status);
                alert('✅ החיבור ל-Make.com עובד תקין!');
            } else {
                console.error('❌ בדיקת webhook נכשלה:', response.status, response.statusText);
                alert('❌ שגיאה בחיבור: ' + response.status);
            }
        } catch (error) {
            console.error('❌ שגיאת רשת:', error);
            alert('❌ שגיאת חיבור: ' + error.message);
        }
    };
    
    // Test all possible formats for Make.com compatibility
    window.testAllFormats = async function() {
        console.log('🧪 בודק את כל הפורמטים הזמינים...');
        
        const testData = {
            fullName: 'רועי טל - בדיקת פורמטים',
            position: 'מומחה AI',
            email: 'test-formats@rt-ai.co.il',
            phone: '052-3299985',
            organization: 'RT-AI Solutions',
            questions: 'בדיקה של פורמטי נתונים שונים ל-Make.com',
            timestamp: new Date().toISOString(),
            source: 'hr-workshop.rt-ai.co.il',
            form_type: 'format_test',
            test_mode: true
        };
        
        // Test 1: JSON format
        console.log('📋 1. מבחן JSON format...');
        try {
            const jsonResponse = await fetch(WEBHOOK_CONFIG.primary, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(testData)
            });
            console.log('JSON Response:', jsonResponse.status, jsonResponse.ok);
        } catch (e) {
            console.log('JSON Failed:', e.message);
        }
        
        // Test 2: Form Data
        console.log('📋 2. מבחן FormData...');
        try {
            const formData = new FormData();
            Object.keys(testData).forEach(key => formData.append(key, testData[key]));
            
            const formResponse = await fetch(WEBHOOK_CONFIG.primary, {
                method: 'POST',
                body: formData
            });
            console.log('FormData Response:', formResponse.status, formResponse.ok);
        } catch (e) {
            console.log('FormData Failed:', e.message);
        }
        
        // Test 3: URL Encoded
        console.log('📋 3. מבחן URLEncoded...');
        try {
            const params = new URLSearchParams();
            Object.keys(testData).forEach(key => params.append(key, testData[key]));
            
            const urlResponse = await fetch(WEBHOOK_CONFIG.primary, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: params
            });
            console.log('URLEncoded Response:', urlResponse.status, urlResponse.ok);
        } catch (e) {
            console.log('URLEncoded Failed:', e.message);
        }
        
        alert('✅ בדיקת פורמטים הושלמה - בדוק קונסול לתוצאות');
    };
    
    // Quick test function for minimal data  
    window.testWebhookQuick = async function() {
        console.log('⚡ בדיקה מהירה של webhook...');
        
        const quickData = {
            email: 'quick-test@example.com',
            name: 'בדיקה מהירה',
            timestamp: new Date().toISOString(),
            source: 'hr-workshop.rt-ai.co.il',
            form_type: 'quick_test',
            test_mode: true
        };
        
        try {
            const response = await fetch(WEBHOOK_CONFIG.primary, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(quickData)
            });
            
            console.log('⚡ תגובה מהירה:', response.status, response.ok);
            const responseText = await response.text();
            console.log('⚡ תוכן תגובה:', responseText);
            
            if (response.ok) {
                alert('✅ Webhook עובד! נתונים בסיסיים נשלחו');
            } else {
                alert('❌ בעיה ב-webhook: ' + response.status);
            }
        } catch (error) {
            console.error('❌ שגיאה:', error);
            alert('❌ שגיאת חיבור: ' + error.message);
        }
    };
    
    // Add test buttons in debug mode
    if (window.location.hostname === 'localhost' || window.location.hostname.includes('127.0.0.1') || window.location.search.includes('debug=true')) {
        console.log('🔧 מצב פיתוח זוהה - הוסף כפתורי בדיקה');
        
        const testButton1 = document.createElement('button');
        testButton1.innerHTML = '🧪 בדיקה מלאה';
        testButton1.className = 'fixed bottom-4 right-4 bg-purple-500 text-white px-3 py-2 rounded-lg shadow-lg z-50 text-xs';
        testButton1.onclick = window.testWebhook;
        document.body.appendChild(testButton1);
        
        const testButton2 = document.createElement('button');
        testButton2.innerHTML = '⚡ בדיקה מהירה';
        testButton2.className = 'fixed bottom-16 right-4 bg-blue-500 text-white px-3 py-2 rounded-lg shadow-lg z-50 text-xs';
        testButton2.onclick = window.testWebhookQuick;
        document.body.appendChild(testButton2);
        
        const testButton3 = document.createElement('button');
        testButton3.innerHTML = '🔄 בדוק כל הפורמטים';
        testButton3.className = 'fixed bottom-28 right-4 bg-orange-500 text-white px-3 py-2 rounded-lg shadow-lg z-50 text-xs';
        testButton3.onclick = window.testAllFormats;
        document.body.appendChild(testButton3);
        
        // Add console helper
        console.log('🚀 פונקציות בדיקה זמינות:');
        console.log('   testWebhook() - בדיקה מלאה');
        console.log('   testWebhookQuick() - בדיקה מהירה');
        console.log('   testAllFormats() - בדיקת כל הפורמטים');
    }

    // Add animation on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe all benefit and feature cards
    document.querySelectorAll('.shadow-lg, .shadow-md').forEach(card => {
        observer.observe(card);
    });

    // Add floating effect on hover for cards
    document.querySelectorAll('.shadow-lg, .shadow-md').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.transition = 'all 0.3s ease';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Header shadow on scroll
    const header = document.querySelector('header');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 10) {
            header.classList.add('shadow-lg');
        } else {
            header.classList.remove('shadow-lg');
        }
    });

    // Countdown timer (optional - for upcoming workshop)
    const countdownElement = document.getElementById('countdown');
    if (countdownElement) {
        const workshopDate = new Date('2025-02-01T10:00:00'); // Set your workshop date
        
        function updateCountdown() {
            const now = new Date();
            const difference = workshopDate - now;
            
            if (difference > 0) {
                const days = Math.floor(difference / (1000 * 60 * 60 * 24));
                const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
                
                countdownElement.innerHTML = `
                    <span class="font-bold">${days}</span> ימים 
                    <span class="font-bold">${hours}</span> שעות 
                    <span class="font-bold">${minutes}</span> דקות
                `;
            } else {
                countdownElement.innerHTML = 'הסדנה התחילה!';
            }
        }
        
        updateCountdown();
        setInterval(updateCountdown, 60000); // Update every minute
    }

    // Mobile menu toggle (if needed in future)
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuToggle && mobileMenu) {
        mobileMenuToggle.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }

    // Form field validation feedback
    const requiredInputs = document.querySelectorAll('input[required], textarea[required]');
    requiredInputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('border-red-500');
                this.classList.remove('border-gray-300');
            } else {
                this.classList.remove('border-red-500');
                this.classList.add('border-gray-300');
            }
        });
        
        input.addEventListener('focus', function() {
            this.classList.remove('border-red-500');
            this.classList.add('border-primary');
        });
    });

    // Email validation
    const emailInput = document.querySelector('input[type="email"]');
    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(this.value) && this.value !== '') {
                this.classList.add('border-red-500');
                this.classList.remove('border-gray-300');
            }
        });
    }

    // Phone validation (Israeli format)
    const phoneInput = document.querySelector('input[type="tel"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function() {
            // Remove non-digit characters
            let value = this.value.replace(/\D/g, '');
            
            // Format as Israeli phone number
            if (value.length > 0) {
                if (value.length <= 3) {
                    this.value = value;
                } else if (value.length <= 6) {
                    this.value = value.slice(0, 3) + '-' + value.slice(3);
                } else {
                    this.value = value.slice(0, 3) + '-' + value.slice(3, 6) + '-' + value.slice(6, 10);
                }
            }
        });
    }

    // Add subtle parallax effect to hero section
    const heroSection = document.querySelector('.gradient-bg');
    if (heroSection) {
        window.addEventListener('scroll', function() {
            const scrolled = window.pageYOffset;
            const parallaxSpeed = 0.5;
            heroSection.style.transform = `translateY(${scrolled * parallaxSpeed}px)`;
        });
    }

    // Copy email to clipboard on click
    const emailLinks = document.querySelectorAll('a[href^="mailto:"]');
    emailLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const email = this.href.replace('mailto:', '');
            
            // Try to copy to clipboard
            if (navigator.clipboard) {
                navigator.clipboard.writeText(email).then(() => {
                    // Show temporary tooltip
                    const tooltip = document.createElement('div');
                    tooltip.className = 'fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-gray-800 text-white px-4 py-2 rounded-lg z-50';
                    tooltip.textContent = 'כתובת המייל הועתקה!';
                    document.body.appendChild(tooltip);
                    
                    setTimeout(() => {
                        tooltip.remove();
                    }, 2000);
                });
            }
        });
    });

    // Animate numbers when they come into view
    const animateNumbers = () => {
        const numbers = document.querySelectorAll('[data-animate-number]');
        numbers.forEach(number => {
            const target = parseInt(number.getAttribute('data-animate-number'));
            const duration = 2000;
            const step = target / (duration / 16);
            let current = 0;
            
            const updateNumber = () => {
                current += step;
                if (current >= target) {
                    number.textContent = target;
                } else {
                    number.textContent = Math.floor(current);
                    requestAnimationFrame(updateNumber);
                }
            };
            
            const numberObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        updateNumber();
                        numberObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.5 });
            
            numberObserver.observe(number);
        });
    };
    
    animateNumbers();

    // Log page performance
    window.addEventListener('load', function() {
        if (window.performance && window.performance.timing) {
            const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart;
            console.log(`Page load time: ${loadTime}ms`);
        }
    });
});

// Add CSS animation class
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .animate-fade-in {
        animation: fadeIn 0.6s ease-out;
    }
`;
document.head.appendChild(style);